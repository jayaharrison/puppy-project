
__version_info__ = ('6', '24', '0')
__version__ = '.'.join(__version_info__)
